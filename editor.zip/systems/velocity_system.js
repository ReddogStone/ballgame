var Ballgame = (function(module) {
	'use strict';

	function VelocitySystem(entitySystem) {
		Jabaku.SystemBase.call(this, entitySystem, function(entity) {
			return entity.contains(Ballgame.Transform);
		});
	}
	VelocitySystem.extends(Jabaku.SystemBase, {
		update: function() {
			for (var i = 0; i < this._entities.length; ++i) {
				var entity = this._entities[i];
				var trans = entity.get(Ballgame.Transform);
				trans.calcTransform();
			}
		}
	});

	module.VelocitySystem = VelocitySystem;
	return module;
})(Ballgame || {});
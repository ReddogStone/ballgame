var Vecmath = (function(module) {
	'use strict';

	var Vector3 = module.Vector3;
	var Matrix3 = module.Matrix3;

	//some shared 'private' arrays
	var s_iNext = (typeof Int8Array !== 'undefined' ? new Int8Array([1,2,0]) : [1,2,0]);
	var tmp = (typeof Float32Array !== 'undefined' ? new Float32Array([0,0,0]) : [0,0,0]);

	var xUnitVec3 = new Vector3(1, 0, 0);
	var yUnitVec3 = new Vector3(0, 1, 0);
	var tmpvec = new Vector3();

	var tmpMat3 = new Matrix3();

	function Quaternion(x, y, z, w) {
		if (typeof x === "object") {
			this.x = x.x||0;
			this.y = x.y||0;
			this.z = x.z||0;
			this.w = x.w||0;
		} else {
			this.x = x||0;
			this.y = y||0;
			this.z = z||0;
			this.w = w||0;
		}
	}

	var quat = Quaternion.prototype;

	quat.clone = function() {
		return new Quaternion(this.x, this.y, this.z, this.w);
	};
	
    quat.copy = function(otherVec) {
        this.x = otherVec.x||0;
        this.y = otherVec.y||0;
        this.z = otherVec.z||0;
        this.w = otherVec.w||0;
        return this;
    };

    quat.set = function(x, y, z, w) {
        if (typeof x === "object") {
            this.x = x.x||0;
            this.y = x.y||0;
            this.z = x.z||0;
            this.w = x.w||0;
        } else {
            this.x = x||0;
            this.y = y||0;
            this.z = z||0;
            this.w = w||0;

        }
        return this;
    };

    quat.add = function(v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
        this.w += v.w;
        return this;
    };

    quat.subtract = function(v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
        this.w -= v.w;
        return this;
    };

    quat.scale = function(s) {
        this.x *= s;
        this.y *= s;
        this.z *= s;
        this.w *= s;
        return this;
    };

	quat.length = function() {
        var x = this.x,
            y = this.y,
            z = this.z,
            w = this.w;
        return Math.sqrt(x*x + y*y + z*z + w*w);
    };

    quat.lengthSq = function() {
        var x = this.x,
            y = this.y,
            z = this.z,
            w = this.w;
        return x*x + y*y + z*z + w*w;
    };

    quat.normalize = function() {
        var x = this.x,
            y = this.y,
            z = this.z,
            w = this.w;
        var len = x*x + y*y + z*z + w*w;
        if (len > 0) {
            len = 1 / Math.sqrt(len);
            this.x = x*len;
            this.y = y*len;
            this.z = z*len;
            this.w = w*len;
        }
        return this;
    };

    quat.dot = function(v) {
        return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w;
    };

    quat.lerp = function(v, t) {
        var ax = this.x,
            ay = this.y,
            az = this.z,
            aw = this.w;
        t = t||0;
        this.x = ax + t * (v.x - ax);
        this.y = ay + t * (v.y - ay);
        this.z = az + t * (v.z - az);
        this.w = aw + t * (v.w - aw);
        return this;
    };

	quat.rotationTo = function(a, b) {
		var dot = a.x * b.x + a.y * b.y + a.z * b.z; //a.dot(b)
		if (dot < -0.999999) {
			if (tmpvec.copy(xUnitVec3).cross(a).len() < 0.000001)
				tmpvec.copy(yUnitVec3).cross(a);
			
			tmpvec.normalize();
			return this.setAxisAngle(tmpvec, Math.PI);
		} else if (dot > 0.999999) {
			this.x = 0;
			this.y = 0;
			this.z = 0;
			this.w = 1;
			return this;
		} else {
			tmpvec.copy(a).cross(b);
			this.x = tmpvec.x;
			this.y = tmpvec.y;
			this.z = tmpvec.z;
			this.w = 1 + dot;
			return this.normalize();
		}
	};

	quat.setAxes = function(view, right, up) {
		var m = tmpMat3.val;
		m[0] = right.x;
		m[3] = right.y;
		m[6] = right.z;

		m[1] = uquat.x;
		m[4] = uquat.y;
		m[7] = uquat.z;

		m[2] = view.x;
		m[5] = view.y;
		m[8] = view.z;

		return this.fromMat3(tmpMat3).normalize();
	};

	quat.identity = function() {
		this.x = this.y = this.z = 0;
		this.w = 1;
		return this;
	};

	quat.setAxisAngle = function(axis, rad) {
		rad = rad * 0.5;
		var s = Math.sin(rad);
		this.x = s * axis.x;
		this.y = s * axis.y;
		this.z = s * axis.z;
		this.w = Math.cos(rad);
		return this;
	};

	quat.multiply = function(b) {
		var ax = this.x, ay = this.y, az = this.z, aw = this.w,
			bx = b.x, by = b.y, bz = b.z, bw = b.w;

		this.x = ax * bw + aw * bx + ay * bz - az * by;
		this.y = ay * bw + aw * by + az * bx - ax * bz;
		this.z = az * bw + aw * bz + ax * by - ay * bx;
		this.w = aw * bw - ax * bx - ay * by - az * bz;
		return this;
	};

	quat.slerp = function (b, t) {
		// benchmarks:
		//    http://jsperf.com/quaternion-slerp-implementations

		var ax = this.x, ay = this.y, az = this.y, aw = this.y,
			bx = b.x, by = b.y, bz = b.z, bw = b.w;

		var        omega, cosom, sinom, scale0, scale1;

		// calc cosine
		cosom = ax * bx + ay * by + az * bz + aw * bw;
		// adjust signs (if necessary)
		if ( cosom < 0.0 ) {
			cosom = -cosom;
			bx = - bx;
			by = - by;
			bz = - bz;
			bw = - bw;
		}
		// calculate coefficients
		if ( (1.0 - cosom) > 0.000001 ) {
			// standard case (slerp)
			omega  = Math.acos(cosom);
			sinom  = Math.sin(omega);
			scale0 = Math.sin((1.0 - t) * omega) / sinom;
			scale1 = Math.sin(t * omega) / sinom;
		} else {        
			// "from" and "to" quaternions are very close 
			//  ... so we can do a linear interpolation
			scale0 = 1.0 - t;
			scale1 = t;
		}
		// calculate final values
		this.x = scale0 * ax + scale1 * bx;
		this.y = scale0 * ay + scale1 * by;
		this.z = scale0 * az + scale1 * bz;
		this.w = scale0 * aw + scale1 * bw;
		return this;
	};

	quat.invert = function() {
		var a0 = this.x, a1 = this.y, a2 = this.z, a3 = this.w,
			dot = a0*a0 + a1*a1 + a2*a2 + a3*a3,
			invDot = dot ? 1.0/dot : 0;
		
		// TODO: Would be faster to return [0,0,0,0] immediately if dot == 0

		this.x = -a0*invDot;
		this.y = -a1*invDot;
		this.z = -a2*invDot;
		this.w = a3*invDot;
		return this;
	};

	quat.conjugate = function() {
		this.x = -this.x;
		this.y = -this.y;
		this.z = -this.z;
		return this;
	};

	quat.rotateX = function (rad) {
		rad *= 0.5; 

		var ax = this.x, ay = this.y, az = this.z, aw = this.w,
			bx = Math.sin(rad), bw = Math.cos(rad);

		this.x = ax * bw + aw * bx;
		this.y = ay * bw + az * bx;
		this.z = az * bw - ay * bx;
		this.w = aw * bw - ax * bx;
		return this;
	};

	quat.rotateY = function (rad) {
		rad *= 0.5; 

		var ax = this.x, ay = this.y, az = this.z, aw = this.w,
			by = Math.sin(rad), bw = Math.cos(rad);

		this.x = ax * bw - az * by;
		this.y = ay * bw + aw * by;
		this.z = az * bw + ax * by;
		this.w = aw * bw - ay * by;
		return this;
	};

	quat.rotateZ = function (rad) {
		rad *= 0.5; 

		var ax = this.x, ay = this.y, az = this.z, aw = this.w,
			bz = Math.sin(rad), bw = Math.cos(rad);

		this.x = ax * bw + ay * bz;
		this.y = ay * bw - ax * bz;
		this.z = az * bw + aw * bz;
		this.w = aw * bw - az * bz;
		return this;
	};

	quat.calculateW = function () {
		var x = this.x, y = this.y, z = this.z;

		this.x = x;
		this.y = y;
		this.z = z;
		this.w = -Math.sqrt(Math.abs(1.0 - x * x - y * y - z * z));
		return this;
	};

	quat.fromMat3 = function(mat) {
		// benchmarks:
		//    http://jsperf.com/typed-array-access-speed
		//    http://jsperf.com/conversion-of-3x3-matrix-to-quaternion

		// Algorithm in Ken Shoemake's article in 1987 SIGGRAPH course notes
		// article "Quaternion Calculus and Fast Animation".
		var m = mat.val,
			fTrace = m[0] + m[4] + m[8];
		var fRoot;

		if ( fTrace > 0.0 ) {
			// |w| > 1/2, may as well choose w > 1/2
			fRoot = Math.sqrt(fTrace + 1.0);  // 2w
			this.w = 0.5 * fRoot;
			fRoot = 0.5/fRoot;  // 1/(4w)
			this.x = (m[7]-m[5])*fRoot;
			this.y = (m[2]-m[6])*fRoot;
			this.z = (m[3]-m[1])*fRoot;
		} else {
			// |w| <= 1/2
			var i = 0;
			if ( m[4] > m[0] )
			  i = 1;
			if ( m[8] > m[i*3+i] )
			  i = 2;
			var j = s_iNext[i];
			var k = s_iNext[j];
				
			//This isn't quite as clean without array access...
			fRoot = Math.sqrt(m[i*3+i]-m[j*3+j]-m[k*3+k] + 1.0);
			tmp[i] = 0.5 * fRoot;

			fRoot = 0.5 / fRoot;
			tmp[j] = (m[j*3+i] + m[i*3+j]) * fRoot;
			tmp[k] = (m[k*3+i] + m[i*3+k]) * fRoot;

			this.x = tmp[0];
			this.y = tmp[1];
			this.z = tmp[2];
			this.w = (m[k*3+j] - m[j*3+k]) * fRoot;
		}
		
		return this;
	};

	quat.idt = quat.identity;

	quat.sub = quat.subtract;

	quat.mul = quat.multiply;

	quat.len = quat.length;

	quat.lenSq = quat.lengthSq;

	//This is handy for Pool utilities, to "reset" a
	//shared object to its default state
	quat.reset = quat.idt;


	quat.toString = function() {
		return 'Quaternion(' + this.x + ', ' + this.y + ', ' + this.z + ', ' + this.w + ')';
	};

	quat.str = quat.toString;

	module.Quaternion = Quaternion;
	return module;
}) (Vecmath || {});
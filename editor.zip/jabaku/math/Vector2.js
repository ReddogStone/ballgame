var Vecmath = (function(module) {
	'use strict';

	function Vector2(x, y) {
		if (typeof x === "object") {
			this.x = x.x||0;
			this.y = x.y||0;
		} else {
			this.x = x||0;
			this.y = y||0;
		}
	}

	//shorthand it for better minification
	var vec2 = Vector2.prototype;

	/**
	 * Returns a new instance of Vector2 with
	 * this vector's components. 
	 * @return {Vector2} a clone of this vector
	 */
	vec2.clone = function() {
		return new Vector2(this.x, this.y);
	};

	/**
	 * Copies the x, y components from the specified
	 * Vector. Any undefined components from `otherVec`
	 * will default to zero.
	 * 
	 * @param  {otherVec} the other Vector2 to copy
	 * @return {Vector2}  this, for chaining
	 */
	vec2.copy = function(otherVec) {
		this.x = otherVec.x||0;
		this.y = otherVec.y||0;
		return this;
	};

	/**
	 * A convenience function to set the components of
	 * this vector as x and y. Falsy or undefined
	 * parameters will default to zero.
	 *
	 * You can also pass a vector object instead of
	 * individual components, to copy the object's components.
	 * 
	 * @param {Number} x the x component
	 * @param {Number} y the y component
	 * @return {Vector2}  this, for chaining
	 */
	vec2.set = function(x, y) {
		if (typeof x === "object") {
			this.x = x.x||0;
			this.y = x.y||0;
		} else {
			this.x = x||0;
			this.y = y||0;
		}
		return this;
	};

	vec2.add = function(v) {
		this.x += v.x;
		this.y += v.y;
		return this;
	};

	vec2.subtract = function(v) {
		this.x -= v.x;
		this.y -= v.y;
		return this;
	};

	vec2.multiply = function(v) {
		this.x *= v.x;
		this.y *= v.y;
		return this;
	};

	vec2.scale = function(s) {
		this.x *= s;
		this.y *= s;
		return this;
	};

	vec2.divide = function(v) {
		this.x /= v.x;
		this.y /= v.y;
		return this;
	};

	vec2.negate = function() {
		this.x = -this.x;
		this.y = -this.y;
		return this;
	};

	vec2.distance = function(v) {
		var dx = v.x - this.x,
			dy = v.y - this.y;
		return Math.sqrt(dx*dx + dy*dy);
	};

	vec2.distanceSq = function(v) {
		var dx = v.x - this.x,
			dy = v.y - this.y;
		return dx*dx + dy*dy;
	};

	vec2.length = function() {
		var x = this.x,
			y = this.y;
		return Math.sqrt(x*x + y*y);
	};

	vec2.lengthSq = function() {
		var x = this.x,
			y = this.y;
		return x*x + y*y;
	};

	vec2.normalize = function() {
		var x = this.x,
			y = this.y;
		var len = x*x + y*y;
		if (len > 0) {
			len = 1 / Math.sqrt(len);
			this.x = x*len;
			this.y = y*len;
		}
		return this;
	};

	vec2.dot = function(v) {
		return this.x * v.x + this.y * v.y;
	};

	//Unlike Vector3, this returns a scalar
	//http://allenchou.net/2013/07/cross-product-of-2d-vectors/
	vec2.cross = function(v) {
		return this.x * v.y - this.y * v.x;
	};

	vec2.lerp = function(v, t) {
		var ax = this.x,
			ay = this.y;
		t = t||0;
		this.x = ax + t * (v.x - ax);
		this.y = ay + t * (v.y - ay);
		return this;
	};

	vec2.transformMat3 = function(mat) {
		var x = this.x, y = this.y, m = mat.val;
		this.x = m[0] * x + m[2] * y + m[4];
		this.y = m[1] * x + m[3] * y + m[5];
		return this;
	};

	vec2.transformMat4 = function(mat) {
		var x = this.x, 
			y = this.y,
			m = mat.val;
		this.x = m[0] * x + m[4] * y + m[12];
		this.y = m[1] * x + m[5] * y + m[13];
		return this;
	};

	vec2.reset = function() {
		this.x = 0;
		this.y = 0;
		return this;
	};
	
	vec2.toArray = function() {
		return [this.x, this.y];
	};	

	vec2.sub = vec2.subtract;

	vec2.mul = vec2.multiply;

	vec2.div = vec2.divide;

	vec2.dist = vec2.distance;

	vec2.distSq = vec2.distanceSq;

	vec2.len = vec2.length;

	vec2.lenSq = vec2.lengthSq;

	vec2.toString = function() {
		return 'Vector2(' + this.x + ', ' + this.y + ')';
	};

	vec2.random = function(scale) {
		scale = scale || 1.0;
		var r = Math.random() * 2.0 * Math.PI;
		this.x = Math.cos(r) * scale;
		this.y = Math.sin(r) * scale;
		return this;
	};

	vec2.str = vec2.toString;

	module.Vector2 = Vector2;
	return module;
}) (Vecmath || {});	